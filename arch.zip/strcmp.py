#[wip]

# define a function
def strcmp(s1, s2):
    print ("I am an strcmp function", s1, s2)
    return s1 == s2
    
    
def main():
    print ("[mst] quick strcmp doodle")
    strcmp ("abc","abd")
    
    
if __name__ == ("__main__"):
    main()