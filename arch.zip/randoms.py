# [mst] helloworld.py 
# python random engine doodles
#
# log:
# -[wip] basic random number generation
# -[wip] random shullfes and sorting
#

import random

value = random.random()
print (value)

value2 = random.randint(1,10)
print(value2)