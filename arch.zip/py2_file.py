#
# [mst] py2_file.py
# this is a simple demo file to be converted to Python3 syntax
#

def main():
    print "hello world!"

if __name__ == ("__main__"):
    main()