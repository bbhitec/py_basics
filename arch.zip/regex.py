#
# [mst] regex.py 
# doodling with regex in python
#
# log:
# -simple regex "match to list" search
# -[wip] replace a match group
#

import re

# with open('py2_file.py') as f:
#     for line in f:
#         match = re.search('print', line)

matches_list = [re.findall(r'print(?!\s*[\(\)])\s*(.*)',line) 
    for line in open('py2_file.py')]

replace_str = 'print'
print (replace_str + str(matches_list[1]))

